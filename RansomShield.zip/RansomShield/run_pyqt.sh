#!/bin/bash
python main_pyqt.py