#!/bin/bash
python main_tkinter.py