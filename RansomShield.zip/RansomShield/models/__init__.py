# Models package directory
# This directory will store the pre-trained CNN and LSTM models in .h5 format